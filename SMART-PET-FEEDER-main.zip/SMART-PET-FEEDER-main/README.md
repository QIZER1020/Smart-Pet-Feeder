# SMART-PET-FEEDER
IoT application to feed your pets when you are away from your home or out of station with just one click through your mobile or google assistant.
